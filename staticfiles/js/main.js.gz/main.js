setTimeout(function(){
    $('#message').fadeOut('slow'); 
 },3000);

//  $(document).ready(function(){
//     $(".close").click(function(){
//       $("x").fadeOut();
//     });
// });